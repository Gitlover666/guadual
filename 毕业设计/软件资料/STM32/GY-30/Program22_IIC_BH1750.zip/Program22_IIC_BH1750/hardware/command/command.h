#ifndef __COMMAND_H
#define __COMMAND_H

#include "sys.h"

#define Information      1                    
#define Reset            2
#define Greenledon       3
#define Help             4



void command_config(unsigned char command);


#endif

