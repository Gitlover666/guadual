#include "command.h"
#include "usart.h"
#include "delay.h"







void command_config(unsigned char command)
{
	
	
		switch(command)
				{
					case 0:
															Sys_Soft_Reset();
															delay_ms(100);
															USART1_Puts("Reset\r\nPass\r\n");
															break;
					case 1:			
															USART1_Puts("Output All Command\r\n");
															USART1_Puts("Reset\r\n");					
															break;
					//case Greenledon:
					//							    	break;
						


								}



}






