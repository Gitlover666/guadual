#ifndef __SYSTICK_H__
#define __SYSTICK_H__

#include "stm32f10x.h"

void Delay_us(u32 us);
void Delay_ms(u16 ms);

#endif

