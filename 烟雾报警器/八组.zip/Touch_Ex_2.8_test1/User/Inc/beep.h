# ifndef __BEEP_H
# define __BEEP_H



void BEEP_Init(void);

# endif 
